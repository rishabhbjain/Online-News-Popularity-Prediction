﻿from flask import Flask, render_template, request
from werkzeug import secure_filename
from flask_cors import CORS
from flask import jsonify
import pickle
import joblib
import os
import numpy as np
import pandas as pd
from flask_restful import Resource, Api
import json
from zipfile import ZipFile
from urllib.request import urlopen
from io import BytesIO
from urllib.request import Request, urlopen


app = Flask(__name__)
CORS(app)

@app.route('/data', methods = ['GET'])
def downloads3_file():
    url = urlopen("https://s3.amazonaws.com/ads-assignment3-models/AllModels.zip")
    path = str(os.path.join(app.instance_path, 'gunjan')) 
    with ZipFile(BytesIO(url.read())) as zfile:
        zfile.extractall(path)
    print("Download complete")
                
clf=joblib.load(os.path.join('AllModels','AdaptiveBoosting.pkl'))
clf1 = joblib.load('AllModels/RandomForest.pkl')
clf2 = joblib.load('AllModels/NaiveBayes.pkl')
clf3 = joblib.load('AllModels/LogisticRegression.pkl')
clf4 = joblib.load('AllModels/SupportVectorMachine.pkl')
clf5 = joblib.load('AllModels/k-NearestNeighbors.pkl')
clf6 = joblib.load('AllModels/DecisionTree.pkl')
clf7 = joblib.load('AllModels/NeuralNetwork.pkl')

@app.route('/dataset')    
def another_page():    
    table = pd.read_csv("modified.csv")
    return render_template("htmldemo.html", data=table.to_html(escape = False))

@app.route('/upload')
def upload_filepage():
   return render_template('upload.html')

@app.route('/uploader', methods = ['GET', 'POST'])
def upload_file1():
      if request.method == 'POST':
          f = request.files['file']
          f.save(os.path.join(app.instance_path, 'gunjan', secure_filename(f.filename)))
          #downloads3_file()
          df = pd.read_csv(os.path.join(app.instance_path, 'gunjan', secure_filename(f.filename)))
          X = df.drop('url',axis = 1)
          print("Data ready for prediction")
          adaptiveBosting=clf.predict(X)
          print("ada done")
          randomForest = clf1.predict(X)
          print("rf done")
          naivebayes = clf2.predict(X)  
          print("nb done")
          logistic = clf3.predict(X) 
          print("lr done")
          svc = clf4.predict(X)
          print("svc done")
          knn = clf5.predict(X)
          print("knn done")
          decisionTree = clf6.predict(X)
          print("dt done")
          neuralNets = clf7.predict(X)
          print("nn done")
          pred = np.array([adaptiveBosting,randomForest,naivebayes,
                                  logistic,svc,knn,decisionTree,neuralNets])
          predictions = pd.DataFrame(data = np.transpose(pred) , columns=['adaptiveBosting','randomForest','naivebayes',
                                  'logistic','svc','knn','decisionTree','neuralNets'])
          predformat = ["mediocre" if i == 0 else "Super Popular" if i == 1 else "viral" if i == 2 else "popular" if i == 3 
                        else "obscure" for i in randomForest]
          
          results =  {'Popularity': predformat}
          
          predictions['URL'] = df.url
          cols = predictions.columns.tolist()
          cols = cols[-1:] + cols[:-1]
          predictions = predictions[cols]
          #predictions["Popularity"] = results
          predictions.to_csv(os.path.join(app.instance_path, 'gunjan','Predictions.csv'),index=False)
          print("Prediction Done")
          
          #jsonfile = jsonify(**modeldict)
          return 'file uploaded successfully and prediction will be given in csv'

@app.route('/',methods=['GET'])
def predictform():
        return render_template('predictform.html')

@app.route('/predict',methods=['POST'])
def predict():
        content = request.json      
        modeldict  = doPrediction(content)

        modelsandvalues = []
        for x in modeldict.items():
             modelsandvalues.append({'model':x[0],'prediction':x[1]})

        return jsonify(modelsandvalues)

def doPrediction(content):  
        #downloads3_file()
        print("Data Fetched")
        n_non_stop_unique_tokens = content['param1']
        avg_positive_polarity = content['param3']
        avg_negative_polarity = content['param4']
        n_unique_tokens = content['param2']

        userProvidedLDA = content['lda']
        LDA_00 = 0
        LDA_01 = 0
        LDA_02 = 0
        LDA_03 = 0
        LDA_04 = 0
        
        if userProvidedLDA == 0:
            LDA_00 = 1
        elif userProvidedLDA == 1:
            LDA_01 = 1
        elif userProvidedLDA == 2:
            LDA_02 = 1
        elif userProvidedLDA == 3:
            LDA_03 = 1
        else:
            LDA_04 = 1
	
        #userProvidedDay = content['selectedDay']
        weekday_is_monday = 0
        weekday_is_tuesday = 0
        weekday_is_wednesday = 0
        weekday_is_thursday = 0
        weekday_is_friday = 0
        weekday_is_saturday = 0
        weekday_is_sunday = 0
        is_weekend = 0

        if content['selectedDay'] == "Monday":
            weekday_is_monday = 1
        elif content['selectedDay'] == "Tuesday":
            weekday_is_tuesday = 1
        elif content['selectedDay'] == "Wednesday":
            weekday_is_wednesday= 1
        elif content['selectedDay'] == "Thursday":
            weekday_is_thursday= 1
        elif content['selectedDay'] == "Friday":
            weekday_is_friday = 1
        elif content['selectedDay'] == "Saturday":
            weekday_is_saturday = 1
            is_weekend = 1
        else: 
            weekday_is_sunday = 1
            is_weekend = 1

        print("Data putting to array")

        x=np.array([LDA_00,LDA_02,is_weekend,weekday_is_friday,weekday_is_monday,weekday_is_thursday,weekday_is_tuesday,weekday_is_wednesday,LDA_04,LDA_01,LDA_03,
                            n_non_stop_unique_tokens,n_unique_tokens,avg_positive_polarity,avg_negative_polarity]).reshape(1,-1)
        
        print("Data ready for prediction")

        adaptiveBosting=clf.predict(x)
        print("ada done")
        randomForest = clf1.predict(x)
        print("rf done")
        naivebayes = clf2.predict(x)  #please change
        print("nb done")
        logistic = clf3.predict(x) #please change
        print("lr done")
        svc = clf4.predict(x)
        print("svc done")
        knn = clf5.predict(x)
        print("knn done")
        decisionTree = clf6.predict(x)
        print("dt done")
        neuralNets = clf7.predict(x)
        print("nn done")
       
        dict = {0:'mediocre',1:'super_popular',2:'viral',3:'popular',4:'obscure'}
        
        print("Prediction Done")
        modeldict = {'Logistic Regression' : dict.get(logistic[(0)]) , 'Random Forest': dict.get(randomForest[(0)]), 'Support vector Machine' : dict.get(svc[(0)]),			
                               'Neural Networks' : dict.get(neuralNets[(0)]) ,'Naive Bayes' : dict.get(naivebayes[(0)]) ,'K-Nearest Neighbours' : dict.get(knn[(0)]),
			'Decision Tree' : dict.get(decisionTree[(0)]), 'Adaptive Bosting': dict.get(adaptiveBosting[(0)])}
        
        return modeldict
        
if __name__ == '__main__':
   app.run(debug = True)